const baseApiUrl = 'http://localhost:8080/api'

export {
    baseApiUrl
}
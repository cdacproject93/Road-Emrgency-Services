package com.eleraning.backend.service;

import com.eleraning.backend.model.User;

public interface BookingService {

	
}

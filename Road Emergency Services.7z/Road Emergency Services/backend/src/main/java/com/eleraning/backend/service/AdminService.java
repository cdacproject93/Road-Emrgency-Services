package com.eleraning.backend.service;

import com.eleraning.backend.model.Admin;


public interface AdminService {

	Admin authenticate(Admin admin);
}
